﻿using System;

namespace PingPong
{
    class Program
    {
        // Platform Sizes
        static public int firstPlayerPlatformSize = 3;
        static public int secondPlayerPlatformSize = 8;

        // First, second and ball coordinates
        static public int ballX = 0;
        static public int ballY = 0;
        static public int firstPlayerPos = 10;
        static public int secondPlayerPos = 5;

        // Scores
        static public int firstPlayerScore = 0;
        static public int secondPlayerScore = 0;

        // Directions of the ball
        static public bool isBallDirectionUp = true;
        static public bool isBallDirectionRight = true;

        static void removeScrollBars()
        {
            // Убираем scroll или буфер
            Console.BufferHeight = Console.WindowHeight;
            Console.BufferWidth = Console.WindowWidth;
        }

        static void placeSymbolAtPosition(int x, int y, char symb)
        {
            // Устанавливаем курсор в позицию (x, y)
            Console.SetCursorPosition(x, y);

            // Выводим символ, переданный в функцию
            Console.Write(symb);
        }
        
        static void placeFirstPlayer()
        {
            for (int y = firstPlayerPos; y < firstPlayerPos + firstPlayerPlatformSize; ++y)
            {
                placeSymbolAtPosition(0, y, '‖');
            }
        }

        static void placeSecondPlayer()
        {
            for (int y = secondPlayerPos; y < secondPlayerPos + secondPlayerPlatformSize; ++y)
            {
                placeSymbolAtPosition(Console.WindowWidth - 1, y, '‖');
            }
        }

        static void placeBallAtStartPosition()
        {
            ballX = Console.WindowWidth / 2;
            ballY = Console.WindowHeight / 2;
        }

        static void setStartPositions()
        {
            firstPlayerPos = Console.WindowHeight / 2 - firstPlayerPlatformSize / 2;
            secondPlayerPos = Console.WindowHeight / 2 - secondPlayerPlatformSize / 2;
            placeBallAtStartPosition();
        }

        static void placeBall()
        {
            placeSymbolAtPosition(ballX, ballY, '•');
        }

        static void printResult()
        {
            Console.SetCursorPosition(Console.WindowWidth / 2 - 1, 0);
            Console.Write("{0}-{1}", firstPlayerScore, secondPlayerScore);
        }

        static void moveFirstPlayerUp()
        {
            if (firstPlayerPos > 0)
                firstPlayerPos--;
        }

        static void moveFirstPlayerDown()
        {
            if (firstPlayerPos < Console.WindowHeight - firstPlayerPlatformSize)
                firstPlayerPos++;
        }

        static void moveSecondPlayerUp()
        {
            if (secondPlayerPos > 0)
                secondPlayerPos--;
        }

        static void moveSecondPlayerDown()
        {
            if (secondPlayerPos < Console.WindowHeight - secondPlayerPlatformSize)
                secondPlayerPos++;
        }

        static void secondPlayerMove()
        {
            if (isBallDirectionUp && (ballX > Console.WindowHeight / 2))
                moveSecondPlayerUp();
            else if (ballX > Console.WindowHeight / 2)
                moveSecondPlayerDown();
        }

        static void moveBall()
        {
            // Проверяем, чтобы мячик не вышел за верхнюю и нижнюю границы
            if (ballY == 0)
            {
                isBallDirectionUp = false;
            }
            if (ballY == Console.WindowHeight - 1)
            {
                isBallDirectionUp = true;
            }

            // Если мячик коснулся правой границы => второй игрок проиграл
            if (ballX == Console.WindowWidth - 1)
            {
                firstPlayerScore++;
                isBallDirectionRight = false;
                isBallDirectionUp = true;
                placeBallAtStartPosition();

                Console.SetCursorPosition(Console.WindowWidth / 2 - 9, Console.WindowHeight / 2 - 1);
                Console.Write("First player wins!");
                Console.ReadKey();
            }
            // Иначе если сяч коснулся левой границы => первый игрок проиграл
            if (ballX == 0)
            {
                secondPlayerScore++;
                isBallDirectionRight = true;
                isBallDirectionUp = true;
                placeBallAtStartPosition();

                Console.SetCursorPosition(Console.WindowWidth / 2 - 9, Console.WindowHeight / 2 - 1);
                Console.Write("Second player wins!");
                Console.ReadKey();
            }

            // Если координаты мяча находятся около вертикальной линии платформы первого игрока,
            if (ballX < 2)
            {
                // то мы проверяем отобьёт ли платформа мяч
                if ((ballY >= firstPlayerPos) && (ballY < firstPlayerPos + firstPlayerPlatformSize))
                {
                    isBallDirectionRight = true;
                    isBallDirectionUp = true;
                }
            }

            // Если координаты мяча находятся около вертикальной линии платформы второго игрока игрока,
            if (ballX > Console.WindowWidth - 1 - 2) // минус 1 - это вертикальная линия перед границой, -2 это вертикальная линия перед линией платформы
            {
                if ((ballY >= secondPlayerPos) && (ballY < secondPlayerPos + secondPlayerPlatformSize))
                {
                    isBallDirectionRight = false;
                    isBallDirectionUp = true;
                }
            }

            // Проверяем, куда двигается мячик (по вертикальной оси)
            if (isBallDirectionUp) --ballY;
            else ++ballY;

            // Проверяем, куда движется мячик по горизонтальной оси
            if (isBallDirectionRight) ++ballX;
            else --ballX;
        }

        static void Main()
        {
            // Удаляем скролл-бар справа от консоли
            removeScrollBars();

            // Задаём всем стартовые позиции (координаты)
            setStartPositions();

            // Main Cycle
            while (true)
            {
                if (Console.KeyAvailable)
                {
                    ConsoleKeyInfo first = Console.ReadKey();
                    if (first.Key == ConsoleKey.UpArrow)
                        moveFirstPlayerUp();
                    else if (first.Key == ConsoleKey.DownArrow)
                        moveFirstPlayerDown();
                }

                secondPlayerMove(); // Искусственный интеллект (2 игрок)
                moveBall(); // Перемещаем мяч
                Console.Clear(); // Каждый раз очищаем консоль, чтобы отрисовать новую картинку
                placeFirstPlayer(); // Размещаем первого игрока
                placeSecondPlayer(); // Размещаем второго игрока
                placeBall(); // Размещаем мяч
                printResult(); // Печатаем результат первого раунда
                
                System.Threading.Thread.Sleep(60); // Приостанавливаем выполнение программы на время, чтобы игра всё время не обновлялась 
            }


            Console.ReadKey();
        }
    }
}
