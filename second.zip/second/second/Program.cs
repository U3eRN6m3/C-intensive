﻿using System;

namespace second
{
    class Program
    {
        public enum BankAccountTypes
        {
            current,
            credit,
            deposit,
            budgetary
        }

        static void Main()
        {
            BankAccountTypes account1 = BankAccountTypes.credit;

            Console.WriteLine(account1);

            Console.ReadKey();
        }
    }
}
