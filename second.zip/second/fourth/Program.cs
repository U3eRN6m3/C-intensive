﻿using System;

namespace fourth
{
    class Program
    {
        public enum University
        {
            MSU,
            MIPT, 
            ITMO,
            MSTU,
            MIT
        }

        public struct Worker
        {
            public string name;
            public string surname;
            public int salary;
            public University university;
        }

        static public void printWorkerInfo(Worker worker)
        {
            Console.WriteLine(worker.name + ' ' + worker.surname);
            Console.WriteLine('{');
            Console.WriteLine("\tSalary => {0}", worker.salary);
            Console.WriteLine("\tUniversity => {0}", worker.university);
            Console.WriteLine('}');
        }

        static void Main()
        {
            Worker worker1;
            worker1.name = "Pedro";
            worker1.surname = "Capone";
            worker1.salary = 10000;
            worker1.university = University.MIT;

            printWorkerInfo(worker1); 

            Console.ReadKey();
        }
    }
}
