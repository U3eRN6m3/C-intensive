﻿using System;

namespace third
{
    class Program
    {
        public enum BankAccountTypes
        {
            current,
            credit,
            deposit,
            budgetary
        }

        public struct BankAccount
        {
            public int id;
            public BankAccountTypes type;
            public decimal balance;
        }

        static void Main()
        {
            BankAccount account1;
            account1.id = 123;
            account1.type = BankAccountTypes.credit;
            account1.balance = 500000;

            Console.WriteLine("Account id => {0}", account1.id);
            Console.WriteLine("Account type => {0}", account1.type);
            Console.WriteLine("Account balance => {0}", account1.balance);

            Console.ReadKey();
        }
    }
}
