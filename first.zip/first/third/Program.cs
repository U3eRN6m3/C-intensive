﻿using System;

namespace third
{
    class Program
    {
        static void Main()
        {
            char ch;
            char.TryParse(Console.ReadLine(), out ch);

            Console.WriteLine((char)((int)ch + 1));

            Console.ReadKey();
        }
    }
}
