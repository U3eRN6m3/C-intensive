﻿using System;

namespace second
{
    class Program
    {
        static void Main()
        {
            int a = int.Parse(Console.ReadLine());
            int b = int.Parse(Console.ReadLine());

            Console.WriteLine((double)a / b);

            Console.ReadKey();
        }
    }
}
