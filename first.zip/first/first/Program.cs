﻿using System;

namespace first
{
    class Program
    {
        static void Main()
        {
            string str;
            str = Console.ReadLine();

            Console.WriteLine("Hello, " + str);

            Console.ReadKey();
        }
    }
}