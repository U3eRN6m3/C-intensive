﻿using System;

namespace fourth
{
    class Program
    {
        static void Main(string[] args)
        {
            int a, b, c;
            int.TryParse(Console.ReadLine(), out a);
            int.TryParse(Console.ReadLine(), out b);
            int.TryParse(Console.ReadLine(), out c);

            if (a != 0 && b != 0 && c != 0)
            {
                double d = b * b - 4 * a * c;
                if (d < 0)
                    Console.WriteLine("There is no roots");
                else if (d == 0)
                {
                    double x = -b / (2 * a);
                    Console.WriteLine("There is one root: {0}", x);
                }
                else
                {
                    d = Math.Sqrt(d);
                    double x1 = Math.Round((-b + d) / (2 * a), 4);
                    double x2 = Math.Round((-b - d) / (2 * a), 4);
                    Console.WriteLine("There is two roots: {0} and {1}", x1, x2);
                }
            }
            else
                Console.WriteLine("Please check input data");


            Console.ReadKey();
        }
    }
}
